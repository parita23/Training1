var express = require('express');
var router = express.Router();
const multer  = require('multer')
var AjaxModel = require('../schema/validationTable');

/* GET home page. */

// const imageStorage = multer.diskStorage({
//   destination: "../public/images",
//   filename: (req, file, cb) => {
//     console.log(file, "file");
//     cb(null, file.originalname);
//   },
// })
// const imageUpload = multer({
//   storage: imageStorage,

// });
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './public/images')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})

const upload = multer({ storage: storage })

router.get('/', function(req, res, next) {
  AjaxModel.find(function(err, db_users_array) {
    if (err) {
        console.log("Error in Fetch Data " + err);
      } else {
        //Print Data in Console
        console.log(db_users_array);
        //Render User Array in HTML Table
        res.render('index', { mydata: db_users_array });
      }
  }).lean();
});

router.post('/add', upload.single('myfile'), async function (req, res, next) {
  console.log("my body data : ",req.body);
  console.log("files",req.file);
  const mybodydata = {
    fName: req.body.fname,
    lName: req.body.lname,
    address: req.body.address,
    gender: req.body.gender,
    hobbies: req.body.hobbies,
    city: req.body.city,
    myfile: req.body.myfile


}
var data = await AjaxModel(mybodydata).save();
if(data){
  res.send(data);
}

});

router.get('/editData/:user_id', async function(req, res) {
  console.log("jgfdhjf");
  console.log(req.params.user_id);
  var data=await AjaxModel.findById(req.params.user_id)
  if (data) {
    console.log("hi",data);
    res.send(data);

} else {
    console.log("Error in Single Record Fetch" + err);
}
});

router.get('/userDelete/:user_id', async function(req, res, next) {
  console.log("Delete Process..");
  AjaxModel.findByIdAndDelete(req.params.user_id, function(err) {
    if (err) {
      console.log("Error in Record Delete " + err);
    } else {
      console.log(" Record Deleted ");
      res.send({type:"success"});
    }
  });
});

module.exports = router;
