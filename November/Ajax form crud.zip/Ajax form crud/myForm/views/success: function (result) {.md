success: function (result) {
                            if (result.type == 'success') {
                                if (result.result) {
                                    let html = `  
                                        <tr>
                                        <td><img src="/images/${result.result.images}" style="width: 100px;" /></td>
                                        <td>${result.result.firstName}</td>
                                        <td>${result.result.address}</td>
                                        <td>${result.result.gender}</td>
                                        <td><button id="${result.result._id}" class="btn1">Edit Details</button><button class="btn btn-danger">Delete Item</button></td>
                                    </tr > `;

                                    console.log(html);

                                    //console.log($("#table").html());
                                    $("#tbody").append(html);
                                }

                            } else {
                                alert(result.message)
                            }
                        },




                         $("#fName").val(data.fName);
                    $("#lName").val(data.lName);
                    $("#address").val(data.address);
                    $('#' + data.gender).attr('checked', true);

                    $("input[type='checkbox']").attr("checked", false);
                    for (let item of data.hobbies) {
                        $("#" + item).attr("checked", "checked");
                    }
                    $("#interestarea").val(data.user_array.interestarea);
                    $('<img class="image" src="/uploads/' + data.user_array.image + '" style="width: 100px;"/>').insertAfter('#image');
                    $("#AddUser").val("Edit user");




















                        let user_id = $(this).attr("id");
                $(".edit").attr("disabled", true);
                $.ajax({
                    url: "/editData/" + user_id,
                    type: "GET",
                    contentType: false,
                    processData: false,
                    success: function (data) {
                        console.log("edit data is : ", data);
                        $("#floatingInput").val(data.fName);
                        $("#floatingInput2").val(data.lName);
                        $("#textArea").val(data.address);
                        $('#' + data.gender).attr('checked', true);

                        let hobbies = data.hobbies.split(",");
                        $("#hobbies")
                            .find("[value=" + hobbies.join("], [value=") + "]")
                            .prop("checked", true);

                        $("#myCity").val(data.city);
                        $('<img class="image" src="/images/' + data.myfile + '" style="width: 100px;"/>').insertAfter('#myfile');
                        $("#submituser").html("Edit user");

                    }

                });